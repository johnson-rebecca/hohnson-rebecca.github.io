//define user Object
function User(location, color, number, result) {
  this.location = location;
  this.color = color;
  this.number = number;
  this.result = result;
}


//Local storage Data
function run() {
    var button = document.getElementById("button");
    button.addEventListener("click", saveData, false);
	document.getElementById("Delete").addEventListener("click", deleteData, false);
	document.getElementById("ClearAll").addEventListener("click", clearAllData, false);
	loadLastUser();
}

function saveData() {
	
    var name = document.getElementById("name").value;
    var location = document.getElementById("location").value;
	var color = document.getElementById("color").value;
	var sel = document.getElementById("choice");
	var number = sel.options[sel.selectedIndex].text;
	var result =  sel.value;
	var myUser =  new User(location, color, number, result);
	
	console.log(myUser);
	
    localStorage.setItem(name,JSON.stringify(myUser));
	localStorage.setItem('latestUser', name); //use this to load lastuser until a user name is entered
    
    display(name);
}

function deleteData() {
	var name = document.getElementById("name").value;
	localStorage.removeItem(name);
}

function clearAllData(){
	localStorage.clear();
}

function display(name){
    var result = document.getElementById("result");
    var user = JSON.parse(localStorage.getItem(name));
    result.innerHTML = "Your name is " +name+ ". And your current location is  "+ user.location +". <br/>" + user.result + ".";
}

//event listener on color selector change
document.getElementById("color").addEventListener("change", watchColorPicker, false);

document.getElementById("name").addEventListener("blur", loadUser, false);

function watchColorPicker(e) {
  var color = document.getElementById("color").value;
  document.querySelectorAll("h1, h3").forEach(function(elem) {
    elem.style.color = color;
  });
}

function loadUser(){
	var name = document.getElementById("name").value;
	if (localStorage.getItem(name) === null) {
	  //do nothing if not found
	}
	else {
		//if user found, then load from local storage
		var user = JSON.parse(localStorage.getItem(name));		
		document.getElementById("location").value = user.location;
		document.getElementById("color").value = user.color;
		setSelectBoxByText('choice', user.number);
		watchColorPicker();		
		display(name);
	}	
}

function loadLastUser(){
	var name = "";
	if (localStorage.getItem('latestUser') === null) {
	  //do nothing if not found
	}
	else {
		//if user found, then load from local storage
		name = localStorage.getItem('latestUser');		
		document.getElementById("name").value = name;
	}
	
	if (localStorage.getItem(name) === null) {
	  //do nothing if not found
	}
	else {
		//if user found, then load from local storage
		var user = JSON.parse(localStorage.getItem(name));		
		document.getElementById("location").value = user.location;
		document.getElementById("color").value = user.color;
		setSelectBoxByText('choice', user.number);
		watchColorPicker();		
		display(name);
	}	
}

function setSelectBoxByText(eid, eTxt) {
    var eid = document.getElementById(eid);
    for (var i = 0; i < eid.options.length; ++i) {
        if (eid.options[i].text === eTxt)
            eid.options[i].selected = true;
    }
}

window.addEventListener("load", run, false);


// Local Storage Oject
function select(){
  var game = document.getElementById("choice").value;
 localStorage.setItem("choice", game);
}

function gameResult(){
 if (typeof(Storage) !== "undefined") {
     var choice= localStorage.getItem("choice");
     alert(choice);  
 } 

}
function gameReset(){
 localStorage.clear();
}